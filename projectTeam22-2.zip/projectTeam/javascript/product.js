// phần js của slide chạy
$(document).ready(function(){
  var swiper = new Swiper('.swiper-container', {
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: {
        delay: 2500,
        disableOnInteraction: false,
    },
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
 },
        navigation: {
           nextEl: '.button-next',
           prevEl: '.button-prev',
       },
  });
        // Phần header scroll
        window.onscroll = function() {myFunction()};

   function myFunction() {
 if (document.body.scrollTop > 250 || document.documentElement.scrollTop > 250) {
    document.getElementById("nav").className = "fixed";
    $(".menu").css("display","none")
} else {
    document.getElementById("nav").className = "";
};
};
        $("#mega-menu").click(function(){
          $(".menu").toggle();
        });

                var modal = document.getElementById('modal');
                var btn = document.getElementById("btn-login");
                var span = document.getElementsByClassName("close")[0];
                var cancelbtn=document.getElementsByClassName("cancelbtn")[0];
                btn.onclick = function() {
                  modal.style.display = "block";
                }
                span.onclick = function() {
                  modal.style.display = "none";
                }
                cancelbtn.onclick= function(){
                  modal.style.display="none";
                }
                window.onclick = function(event) {
                  if (event.target == modal) {
                    modal.style.display = "none";
                  }
                }
});
$(document).ready(function ($) {
if ($(window).scrollTop() > 200) {
            $('.scrollTop').fadeIn();
      } else {
            $('.scrollTop').fadeOut();
      }

$(window).scroll(function () {
        if ($(this).scrollTop() > 200) {
    $('.scrollTop').fadeIn();
        } else {
              $('.scrollTop').fadeOut();
        }
});

$('.scrollTop').click(function () {
        $("html, body").animate({
              scrollTop: 0
        }, 600);
        return false;
});
});
      